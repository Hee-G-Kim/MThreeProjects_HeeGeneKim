package com.mthree.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="dept2")
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "dname")
	private String deptName;
	//@OneToMany(targetEntity=Employee.class, mappedBy="dept")//-relationship owner is this employee entity
	@OneToMany(targetEntity=Employee.class,cascade=CascadeType.ALL )
	@JoinColumn(name = "dept_id") //@JoinColumn  and mappedBy Attribute cannot be used together
	//-relationship owner is department entity
	private List<Employee> employees;
	
	public Department() {
	}
	public Department( String dptName) {
	
		this.deptName = dptName;
	}
	public Department(int id, String dptName) {
		this.id = id;
		this.deptName = dptName;
	}
	public Department(int id, String dptName, List<Employee> employees) {
		super();
		this.id = id;
		this.deptName = dptName;
		this.employees = employees;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the dptName
	 */
	public String getDptName() {
		return deptName;
	}
	/**
	 * @param dptName the dptName to set
	 */
	public void setDptName(String dptName) {
		this.deptName = dptName;
	}
	/**
	 * @return the employees
	 */
	public List<Employee> getEmployees() {
		return employees;
	}
	/**
	 * @param employees the employees to set
	 */
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
	
	
}
