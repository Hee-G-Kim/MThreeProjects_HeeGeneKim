package com.sg.foundations.basics.arrays;

public class ARainbow {

	public static void main(String[] args) {
		
		String[] colors = {"Red", "Orange",
				"Yellow","Green","Blue","Indigo","Violet",
		};
		System.out.println(colors[0]);
		System.out.println(colors[1]);
		System.out.println(colors[2]);
		System.out.println(colors[3]);
		System.out.println(colors[4]);
		System.out.println(colors[5]);
		System.out.println(colors[6]);

	}

}
