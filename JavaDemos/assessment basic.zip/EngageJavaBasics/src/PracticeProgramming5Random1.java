
public class PracticeProgramming5Random1 {

	public static void main(String[] args) {
		

	}

}
