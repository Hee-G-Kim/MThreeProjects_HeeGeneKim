package com.mthree.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "dpt2")
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "dname")
	private String dptName;
	//@OneToMany(targetEntity=Employee.class, mappedBy="dpt") // Because of mappedBy attribute relationship owner is not this 
															// Department Entity but the opposite being Employee. The relationship owner is Employee.
	@OneToMany(targetEntity=Employee.class, cascade = CascadeType.ALL)
	
	@JoinColumn(name = "dptId") // @JoinColumn and mapedBy attribute cannot be given can't be used together. Relationship owner is now this Department Entity
	private List<Employee> employees;
	
	public Department() {
		
	}

	public Department(int id, String dptName, List<Employee> employees) {
		super();
		this.id = id;
		this.dptName = dptName;
		this.employees = employees;
	}
	
	public Department(int id, String dpt) {
			this.id = id;
			this.dptName = dpt;
		}
	
	public Department(String dpt) {
		this.dptName = dpt;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDptName() {
		return dptName;
	}

	public void setDptName(String dptName) {
		this.dptName = dptName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
		
	
	
}
