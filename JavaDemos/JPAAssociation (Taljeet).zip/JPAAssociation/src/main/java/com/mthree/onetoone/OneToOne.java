package com.mthree.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.mthree.onetoone.Address;
import com.mthree.onetoone.Employee;
import com.mthree.utility.EntityManagerHelper;

public class OneToOne {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		Employee e = new Employee();
		e.setFname("Taljeet");
		e.setLname("Singh");
		Address a = new Address("Sydney", 2000);
		e.setAddr(a);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(e);
		tx.commit();

	}

}
