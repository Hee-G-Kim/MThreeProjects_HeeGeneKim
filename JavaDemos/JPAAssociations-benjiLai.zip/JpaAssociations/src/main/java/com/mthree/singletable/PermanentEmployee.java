package com.mthree.singletable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "PE")
public class PermanentEmployee extends Employee {
	private int bonus;

	public PermanentEmployee() {}
	
	public PermanentEmployee(String fname, String lname, int bonus) {
		super(fname, lname);
		this.bonus = bonus;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
}
