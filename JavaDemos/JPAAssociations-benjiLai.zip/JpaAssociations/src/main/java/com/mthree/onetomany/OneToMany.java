package com.mthree.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.mthree.onetomany.Employee;
import com.mthree.utility.EntityManagerHelper;

public class OneToMany {

	public static void main(String[] args) {
		EntityManager em = EntityManagerHelper.getEntityManager();

		Employee e1 = new Employee("Ben", "Lai");
		Employee e2 = new Employee("Bob", "Builder");
		Employee e3 = new Employee("John", "Ross");
		Department dept1 = new Department("Technology");
		Department dept2 = new Department("Finance");
		List<Employee> empList = new ArrayList<>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
//		dept1.setEmps(empList);
		dept2.setEmps(empList);
//		e1.setDept(dept1);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(dept1);
		em.persist(dept2);
//		em.persist(e1);
		tx.commit();
	}

}
