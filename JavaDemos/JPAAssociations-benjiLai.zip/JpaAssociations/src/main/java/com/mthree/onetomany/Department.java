package com.mthree.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "dept2")
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "dname")
	private String name;
	//@OneToMany(targetEntity=Employee.class, mappedBy="dept") // Because of mappedBy attribute, relationship owner is not this Department entity, but the opposite, it is Employee entity
	@OneToMany(targetEntity=Employee.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "dptId") // JoinColumn and mappedBy attribute cannot be used together. Relationship owner is now the Department entity. 
	private List<Employee> emps;
	
	public Department() {
		
	}
	
	public Department(String name) {
		super();
		this.name = name;
	}
	
	public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Department(int id, String name, List<Employee> emps) {
		super();
		this.id = id;
		this.name = name;
		this.emps = emps;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Employee> getEmps() {
		return emps;
	}

	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}
	
	
	
	
}
