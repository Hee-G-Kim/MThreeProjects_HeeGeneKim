package com.mthree.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.mthree.manytomany.Employee;
import com.mthree.utility.EntityManagerHelper;

public class ManyToMany {

	public static void main(String[] args) {
		EntityManager em = EntityManagerHelper.getEntityManager();

		Employee e1 = new Employee("Ben", "Lai");
		Employee e2 = new Employee("Bob", "Builder");
		Employee e3 = new Employee("John", "Ross");
		// Create two lists of Employees
		List<Employee> javaExperts = new ArrayList<>();
		javaExperts.add(e1);
		javaExperts.add(e2);
		
		List<Employee> pythonExperts = new ArrayList<>();
		pythonExperts.add(e1);
		pythonExperts.add(e3);
		
		TechSkill t1 = new TechSkill("Java");
		TechSkill t2 = new TechSkill("Python");
		
		t1.setEmployees(javaExperts);
		t2.setEmployees(pythonExperts);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(e1);
		em.persist(e2);
		em.persist(e3);
		em.persist(t1);
		em.persist(t2);
		tx.commit();
	}

}
