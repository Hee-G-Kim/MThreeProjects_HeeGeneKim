package com.mthree.tableperclass;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "permanentempl5")
public class PermanentEmployee extends Employee {
	private int bonus;

	public PermanentEmployee() {}
	
	public PermanentEmployee(String fname, String lname, int bonus) {
		super(fname, lname);
		this.bonus = bonus;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
}
