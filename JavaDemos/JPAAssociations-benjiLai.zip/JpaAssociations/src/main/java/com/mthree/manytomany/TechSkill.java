package com.mthree.manytomany;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.ManyToMany;

@Entity
@Table(name = "techskill3")
public class TechSkill {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "skillName")
	private String skillName;
	@ManyToMany(targetEntity=Employee.class)
	private List<Employee> employees;

	public TechSkill() {}
	
	public TechSkill(String skillName) {
		super();
		this.skillName = skillName;
	}

	public TechSkill(int id, String skillName, List<Employee> employees) {
		super();
		this.id = id;
		this.skillName = skillName;
		this.employees = employees;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
